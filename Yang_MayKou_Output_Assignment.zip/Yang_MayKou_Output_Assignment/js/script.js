/*
May Kou Yang
SDI Section 2
MDV2330-O
Week 1
Output Assignment
 */

//alert("Javascript is functioning.")

//Variables

var vehicleYear = "2013";
var  vehicleMake = "Honda";
var vehicleModel = "Accord";
var stickerPrice = 25000;
var family = true;

//Outputs

console.log("My first vehicle purchase!");
console.log("It is a year " + vehicleYear + " vehicle.");
console.log("The Make of the vehicle is " + vehicleMake + ".");
console.log("Then the Model of of my vehicle is an " + vehicleModel + ".");
console.log("The vehicle had a sticker price of $" + stickerPrice + ".");
console.log("It is " + family + " that my family has never purchased a " + vehicleMake + " before.");
console.log("I can honestly say that I'm a proud owner of a " + vehicleMake + " " + vehicleModel + ".");